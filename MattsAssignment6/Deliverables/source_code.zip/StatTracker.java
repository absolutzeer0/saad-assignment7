import java.util.ArrayList;

public class StatTracker {
	/**
	 * Member variables
	 */
	private int recordCt;
	private int studentCt;
	private int studentNoClassCt;
	private int instructorCt;
	private int instructorNoTeachCt;
	private int courseCt;
	private int courseNoStudentCt;
	private int courseFallCt;
	private int courseSpringCt;
	private int courseSummerCt;
	
	public ArrayList<Request> requests = new ArrayList<Request>();
	public ArrayList<Record> records = new ArrayList<Record>();
	
	
	
	/**
	 * Constructors
	 */
	public StatTracker(){
		setRecordCt(0);
		setStudentCt(0);
		setStudentNoClassCt(0);
		setInstructorCt(0);
		setInstructorNoTeachCt(0);
		setCourseCt(0);
		setCourseNoStudentCt(0);
		setCourseFallCt(0);
		setCourseSpringCt(0);
		setCourseSummerCt(0);;
	}
	
	//Methods
	/*void printDigestFormat(){
		System.out.println(getRecordCt());
		System.out.println(getStudentCt());
		System.out.println(getStudentNoClassCt());
		System.out.println(getInstructorCt());
		System.out.println(getInstructorNoTeachCt());
		System.out.println(getCourseCt());
		System.out.println(getCourseNoStudentCt());
		System.out.println(getCourseFallCt());
		System.out.println(getCourseSpringCt());
		System.out.println(getCourseSummerCt());
	} */
	
	void printDigestFormat(){
		System.out.println(getRequestCt());
		System.out.println(getGrantedRequestCt());
		System.out.println(getInvalidPrereqCt());
		System.out.println(getInvalidRetakeCt());
		System.out.println(getInvalidSeatsCt());
	}
	
	public int getRequestCt(){
		return requests.size();
	}
	public int getGrantedRequestCt(){
		int ct = 0;
		for(Request req:requests){
			if (req.granted){
				ct++;
			}
		}
		return ct;
	}
	public int getInvalidPrereqCt(){
		int ct = 0;
		for(Request req:requests){
			if (req.deniedPrereqs){
				ct++;
			}
		}
		return ct;
	}
	public int getInvalidRetakeCt(){
		int ct = 0;
		for(Request req:requests){
			if (req.deniedInvalidRetake){
				ct++;
			}
		}
		return ct;
	}
	public int getInvalidSeatsCt(){
		int ct = 0;
		for(Request req:requests){
			if (req.deniedSeats){
				ct++;
			}
		}
		return ct;
	}
	
	//Getters and setters
	public int getRecordCt() {
		return recordCt;
	}
	public void setRecordCt(int recordCt) {
		this.recordCt = recordCt;
	}
	public int getStudentCt() {
		return studentCt;
	}
	public void setStudentCt(int studentCt) {
		this.studentCt = studentCt;
	}
	public int getStudentNoClassCt() {
		return studentNoClassCt;
	}
	public void setStudentNoClassCt(int studentNoClassCt) {
		this.studentNoClassCt = studentNoClassCt;
	}
	public int getInstructorCt() {
		return instructorCt;
	}
	public void setInstructorCt(int instructorCt) {
		this.instructorCt = instructorCt;
	}
	public int getInstructorNoTeachCt() {
		return instructorNoTeachCt;
	}
	public void setInstructorNoTeachCt(int instructorNoTeachCt) {
		this.instructorNoTeachCt = instructorNoTeachCt;
	}
	public int getCourseCt() {
		return courseCt;
	}
	public void setCourseCt(int courseCt) {
		this.courseCt = courseCt;
	}
	public int getCourseNoStudentCt() {
		return courseNoStudentCt;
	}
	public void setCourseNoStudentCt(int courseNoStudentCt) {
		this.courseNoStudentCt = courseNoStudentCt;
	}
	public int getCourseFallCt() {
		return courseFallCt;
	}
	public void setCourseFallCt(int courseFallCt) {
		this.courseFallCt = courseFallCt;
	}
	public int getCourseSpringCt() {
		return courseSpringCt;
	}
	public void setCourseSpringCt(int courseSpringCt) {
		this.courseSpringCt = courseSpringCt;
	}
	public int getCourseSummerCt() {
		return courseSummerCt;
	}
	public void setCourseSummerCt(int courseSummerCt) {
		this.courseSummerCt = courseSummerCt;
	}
	
	
}
