
public class Request {
	public Student student;
	public Course course;
	public boolean granted = false;;
	public boolean deniedPrereqs = false;;
	public boolean deniedInvalidRetake = false;;
	public boolean deniedSeats = false;
	
	Request(Student s, Course c){
		student = s;
		course = c;
	}
	
	public boolean verifyCourseQualifications(){
		boolean completePrereqs = arePrereqsComplete();
		boolean validRetake = isQualifiedRetake();
		boolean seatsAvail = areSeatsAvailable();
		if (completePrereqs && validRetake && seatsAvail &&
				student.getCurrentCourses().size() <= 5){
			granted = true;
			return true;
		}
		if(!completePrereqs){
			
			deniedPrereqs = true;
			return false;
		}
		if (!validRetake){
			
			deniedInvalidRetake = true;
			return false;
		}
		if (!seatsAvail){
			
			deniedSeats = true;
			return false;
		}
		return false;
	}
	public boolean arePrereqsComplete(){

		//If all prereqs are in the records list with a grade of A,B,C, or D
		//then return true. Otherwise, return false.
		int numPrereqs = course.prerequisiteCourseIDs.size();
		
		//Return true if no prereqs
		if (numPrereqs == 0){
			return true;
		}
		
		int prereqCt = 0;
		for (String id:course.prerequisiteCourseIDs){
			
			//If the current prereq was not found, return false. Otherwise,
			//increment the counter if it has a passing grade. Return true
			//if all prereqs have been satisfied.
			Record foundRecord = findRecordFromID(id);
			if (foundRecord == null){
				return false;
			}
			else{
				char grade = foundRecord.getLetterGrade();
				if ((Character.toUpperCase(grade) == 'A') ||
						(Character.toUpperCase(grade) == 'B') ||
						(Character.toUpperCase(grade) == 'C') ||
						(Character.toUpperCase(grade) == 'D')){
					prereqCt++; //increment the prereq counter
					if (prereqCt == numPrereqs){
						return true;
					}
				}
			}	
		}
		return false;
	}
	public boolean isQualifiedRetake(){
		Record foundRecord = findRecordFromID(course.getCourseID());
		
		//If the course is a re-take and has a grade of D or F only,
		//then it is a qualified re-take.
		if (foundRecord == null){
			return true; //not a re-take
		}
		else{
			char grade = foundRecord.getLetterGrade();
			if ((Character.toUpperCase(grade) == 'D') ||
					(Character.toUpperCase(grade) == 'F')){
						return true;
			}
		}
		
		return false;
	}
	public boolean areSeatsAvailable(){
		if (course.getNumSeats() > 0){
			return true;
		}
		return false;
	}
	public Record findRecordFromID(String id){	
		//For all the records held in the tracker, if the course ID of the record
		//matches the course id provided and the student id of the record matches the
		for (Record record:CMS_IMP.tracker.records){
			if (record.getCourse().getCourseID().equals(id) &&
					record.getStudent().getUUID().equals(student.getUUID())){
				return record;
			}
		}
		return null;
	}
}
