import java.util.ArrayList;

public class Record {

	//class members
	private char letterGrade;
	private ArrayList<String> instructorComments = new ArrayList<String>();
	private boolean currentRecord;
	private Course course;
	private Instructor instructor;
	private Student student;
	
	//Constructors
	public Record(Course c,
					Instructor i,
					char g,
					Student s,
					String... comments){
		setCourse(c);
		setInstructor(i);
		setLetterGrade(g);
		setStudent(s);
		
		for (String comment:comments){
			addComment(comment);
		}
	}
	
	public Record(Course c, 
					char g,  
					boolean isCurrent, 
					Instructor i,
					Student s,
					String...comments){
		setCourse(c);
		setLetterGrade(g);
		setCurrentRecord(isCurrent);
		setInstructor(i);
		setStudent(s);
		
		for (String comment:comments){
			addComment(comment);
		}
	}
	
	public Record(Course c,
			Instructor i,
			char g,
			Student s,
			ArrayList<String> comments){
			setCourse(c);
			setLetterGrade(g);
			setInstructor(i);
			setStudent(s);
			instructorComments = comments;
	}
	
	//Methods
	public void addComment(String comment){
		instructorComments.add(comment);
	}
	public boolean removeComment(String comment){
		if (instructorComments.contains(comment)){
			instructorComments.remove(comment);
			return true;
		}
		else{
			return false;
		}
	}
	
	//Getters and Setters
	public char getLetterGrade() {
		return letterGrade;
	}
	public void setLetterGrade(char letterGrade) {
		this.letterGrade = letterGrade;
	}
	public boolean isCurrentRecord() {
		return currentRecord;
	}
	public void setCurrentRecord(boolean isCurrentRecord) {
		this.currentRecord = isCurrentRecord;
	}
	public Course getCourse() {
		return course;
	}
	public void setCourse(Course course) {
		this.course = course;
	}
	public Instructor getInstructor() {
		return instructor;
	}
	public void setInstructor(Instructor instructor) {
		this.instructor = instructor;
	}
	public ArrayList<String> getInstructorComments(){
		return instructorComments;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}
}
