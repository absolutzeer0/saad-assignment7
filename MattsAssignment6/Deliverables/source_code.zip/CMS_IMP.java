import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.ArrayList;

public class CMS_IMP {
	
	static StatTracker tracker = new StatTracker();
	
	static ArrayList<String> filenames = new ArrayList<String>();
	static ArrayList<Scanner> scanners = new ArrayList<Scanner>();
	
	static ArrayList<Student> students = new ArrayList<Student>();
	static ArrayList<Instructor> instructors = new ArrayList<Instructor>();
	static ArrayList<Course> courses = new ArrayList<Course>();
	
	
	public static void main(String[] args) {
		
		filenames.add("students.csv");
		filenames.add("instructors.csv");
		filenames.add("courses.csv");
		filenames.add("records.csv");
		filenames.add("prereqs.csv");
		filenames.add("assignments.csv");
		filenames.add("requests.csv");
		
		//Read information from files and handle according to what 
		//type of input it is.
		String[] tokens;
		for (int i=0; i<filenames.size(); i++){
			
			try {
				scanners.add(new Scanner(new File(filenames.get(i))));
				scanners.get(i).useDelimiter(",");
				
				while (scanners.get(i).hasNextLine()){
					tokens = scanners.get(i).nextLine().split(",");
					
					//populate the appropriate list according to type while
					//keeping track of counts in tracker object.
					handleFileInput(tokens,i);
				}
				scanners.get(i).close();
				
				
				
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}	
		
		//Find all students that have not taken any classes
		findStudentStats();
		
		//Find all courses that haven't been taken by any students
		//and the count for each semester.
		findCourseStats();
		
		//Find all instructors who haven't taught any classes
		findInstructorStats();
		
		//Print to the console in digest format
		tracker.printDigestFormat();
		
		//Open Main console
		openConsole();
			
		
	}
	
	//Methods
	static void openConsole(){
		Scanner reader = new Scanner(System.in);
		String in = "";
		while (!in.toLowerCase().equals("quit")){
			System.out.print("$main: ");
			in = reader.nextLine();
			String[] inParts = in.split(",");
			switch(inParts[0]){
				case "quit":
					System.out.println("> stopping the command loop");
					reader.close();
					break;
				case "display_requests":
					displayRequests();
					break;
				case "display_seats":
					displaySeats();
					break;
				case "display_records":
					displayRecords();
					break;
				case "check_request":
					checkRequest(inParts);
					break;
				case "add_record":
					addRecord(inParts);
					break;
				case "add_seats":
					addSeats(inParts);
					break;
				default:
					System.out.println("Not a valid entry. Please try again.");
					break;
			}
		}
		
	}
	static void addSeats(String[] inParts){
		Course course = new Course();
		course = findCourse(course,inParts[1]);
		course.setNumSeats(course.getNumSeats() + Integer.parseInt(inParts[2]));
	}
	static void addRecord(String[] inParts){
		Student student = new Student();
		Course course = new Course();
		Instructor instructor = new Instructor();
		char grade;
		ArrayList<String> comments = new ArrayList<String>();
		if(inParts.length >= 6){
			student = findStudent(student,inParts[1]);
			course = findCourse(course,inParts[2]);
			instructor = findInstructor(instructor,inParts[3]);
			grade = inParts[inParts.length-1].charAt(0);
			for(int i=4; i<inParts.length-1; ++i){
				comments.add(inParts[i]);
			}
			Record newRec = new Record(course,instructor,grade,student,comments);
			tracker.records.add(newRec);
		}
		
	}
	static void checkRequest(String[] inParts){
		Student student = new Student();
		Course course = new Course();
		if (inParts.length == 3){
			student = findStudent(student,inParts[1]);
			course = findCourse(course,inParts[2]);
			Request request = new Request(student,course);
			if (request.verifyCourseQualifications()){
				request.granted = true;
				tracker.requests.add(request);
				System.out.println("request is valid");
				student.addCurrentCourse(course);
				course.addEnrolledStudent(student);
			}
			else if(request.deniedPrereqs){
				System.out.println("> student is missing one or more prerequisites");
			}
			else if(request.deniedInvalidRetake){
				System.out.println("> student has already taken the course with a grade of C or higher");
			}
			else if(request.deniedSeats){
				System.out.println("> no remaining seats available for the course at this time");
			}
			
		}
		else{
			System.out.print("Please use format: check_request,<studentID>,<courseID>");
		}
	}
	static void displayRecords(){
		String comma = ", ";
		for(Record record:tracker.records){
			System.out.print(record.getStudent().getUUID() + comma +
					record.getCourse().getCourseID() + comma +
					record.getInstructor().getUUID() + comma);
			for(String comment:record.getInstructorComments()){
				System.out.print(comment + comma);
			}
			System.out.println(record.getLetterGrade());
		}
	}
	static void displaySeats(){
		String comma = ", ";
		for(Course course:courses){
			System.out.println(course.getCourseID() + comma +
								course.getTitle() + comma +
								course.getNumSeats());
		}
	}
	static void displayRequests(){
		String comma = ", ";
		for (Request req:tracker.requests){
			if (req.granted){
				System.out.println(req.student.getUUID() + comma +
									req.student.getName() + comma +
									req.course.getCourseID() + comma +
									req.course.getTitle());
			}
		}
	}
	static void handleFileInput(String[] tokens, int i){
		
		Student foundStudent = new Student();
		Course foundCourse = new Course();
		Instructor foundInstructor = new Instructor();
		
		
		switch (i){
			//students
			case 0: 
				Student saveStudent = new Student(tokens);
				students.add(saveStudent);
					
				//Update the statistics tracker
				tracker.setStudentCt(tracker.getStudentCt()+1);
				break;
			//instructors
			case 1: 
				Instructor saveInst = new Instructor(tokens);
				instructors.add(saveInst);
				
				//Update the statistics tracker
				tracker.setInstructorCt(tracker.getInstructorCt()+1);
				break;
			//courses
			case 2: 
				Course saveCourse = new Course(tokens);
				courses.add(saveCourse);
					
				//Update the statistics tracker
				tracker.setCourseCt(tracker.getCourseCt()+1);
				break;
			//records
			case 3: 
				foundStudent = findStudent(foundStudent,tokens[0]);
				foundCourse = findCourse(foundCourse,tokens[1]);
				foundInstructor = findInstructor(foundInstructor,tokens[2]);	
				
				foundStudent.addCurrentCourse(foundCourse);
				foundCourse.addEnrolledStudent(foundStudent);
				foundCourse.setNumSeats(foundCourse.getNumSeats() + 1); //Make up for the removal of a seat in previous line execution
				foundCourse.currentInstructors.add(foundInstructor);
				foundInstructor.addCurrentCourse(foundCourse);
				
				Record saveRecord = new Record(foundCourse,
						foundInstructor,
						tokens[4].charAt(0),
						foundStudent,
						tokens[3]);
				
				//Update the statistics tracker
				tracker.setRecordCt(tracker.getRecordCt()+1);
				tracker.records.add(saveRecord);
				break;
			//prereqs
			case 4:
				foundCourse = findCourse(foundCourse,tokens[1]);
				
				//If the course is in the "courses" list, add the prereq Course
				if (!foundCourse.getCourseID().isEmpty()){
					foundCourse.prerequisiteCourseIDs.add(tokens[0]);
				}
				
				break;
			//assignments
			case 5:
				foundCourse = findCourse(foundCourse,tokens[1]);
				
				//If the course is in the "courses" list, add the instructor
				//to current instructors and increase the numSeats
				if (!foundCourse.getCourseID().isEmpty()){
					foundInstructor = findInstructor(foundInstructor,tokens[0]);
					foundInstructor.addCurrentCourse(foundCourse);
					
					//If the instructor is not already on the list, add them.
					if (!foundCourse.currentInstructors.contains(foundInstructor)){
						foundCourse.currentInstructors.add(foundInstructor);
					}
					int currNumSeats = foundCourse.getNumSeats();
					int toAdd = Integer.parseInt(tokens[2]);
					foundCourse.setNumSeats(currNumSeats + toAdd);
				}
				
				break;
			//requests
			case 6:
				foundCourse = findCourse(foundCourse,tokens[1]);
				foundStudent = findStudent(foundStudent,tokens[0]);
				Request currRequest = new Request(foundStudent,foundCourse);
				
				//If the request is valid, then enroll the student, otherwise deny them.
				if (!foundCourse.getCourseID().isEmpty() &&
						!foundStudent.getName().isEmpty()){
					if (currRequest.verifyCourseQualifications()){
						foundCourse.addEnrolledStudent(foundStudent);
						foundStudent.addCurrentCourse(foundCourse);
					}
					else{
						foundCourse.deniedQueue.add(foundStudent);
					}
				}
				
				//Update Tracker
				tracker.requests.add(currRequest);
				break;
			default:
					break;
		}
	}
	
	// Find the student that was indicated in tokens
	static Student findStudent(Student foundStudent, String token){
		
		
		for (Student student:students){
			
			if (student.getUUID().equals(token)){
				foundStudent = student;
				return foundStudent;
			}
			else{
				// TODO return student not found
			}	
		}
		return foundStudent;
		
	}
	
	// Find the course that was indicated in tokens
	static Course findCourse(Course foundCourse, String token){
		
		for (Course course:courses){
			if (course.getCourseID().equals(token)){
				foundCourse = course;
				return foundCourse;
			}
			else{
				// TODO return course not found
			}
		}
		return foundCourse;
		
	}
	
	// Find the instructor that was indicated in tokens
	static Instructor findInstructor(Instructor foundInstructor, 
			String token){
		
		for (Instructor instr:instructors){
			if (instr.getUUID().equals(token)){
				foundInstructor = instr;
				return foundInstructor;
			}
			else{
				// TODO return instructor not found
			}
		}
		return foundInstructor;
	}
	
	// Find all students that have not taken any classes
	static void findStudentStats(){
		
		for (Student student:students){
			if (!((student.countCurrentCourses() > 0) ||
					(student.countPastCourses() > 0))){
				tracker.setStudentNoClassCt(tracker.getStudentNoClassCt() + 1);
			}
			else{
				
			}
			
		}
		
	}
	
	//  Find all courses that haven't been taken by any students
	//  and the count for each semester.
	static void findCourseStats(){
		
		for (Course course:courses){
			if (course.countEnrolledStudents() <= 0){
				tracker.setCourseNoStudentCt(tracker.getCourseNoStudentCt()+1);
			}
			
			for (String semester:course.getSemesterList()){
				switch (semester.toLowerCase()){
					case "fall":	
						tracker.setCourseFallCt(tracker.getCourseFallCt()+1);
						break;
					case "spring":
						tracker.setCourseSpringCt(tracker.getCourseSpringCt()+1);
						break;
					case "summer":
						tracker.setCourseSummerCt(tracker.getCourseSummerCt()+1);
						break;
						
				}
			}
		}
		
	}
	
	//  Find all instructors who haven't taught any classes
	static void findInstructorStats(){
		
		for (Instructor inst:instructors){
			if ((inst.countCurrentCourses() <= 0) && 
					(inst.countPastCourses() <= 0)){
				tracker.setInstructorNoTeachCt(tracker.getInstructorNoTeachCt()+1);
			}
		}
		
	}
	
	
}
