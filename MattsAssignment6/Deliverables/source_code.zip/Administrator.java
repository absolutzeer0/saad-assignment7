
public class Administrator extends Person{
	
	
	//methods
	private void createStudent(Student student){
		// TODO
	}
	private void removeStudent(Student student){
		// TODO
	}
	private void editStudent(Student student){
		// TODO 
	}
	private void createInstructor(Instructor instructor){
		// TODO
	}
	private void removeInstructor(Instructor instructor){
		// TODO
	}
	private void editInstructor(Instructor instructor){
		// TODO 
	}
	private void createCounselor(Counselor counselor){
		// TODO
	}
	private void removeCounselor(Counselor counselor){
		// TODO
	}
	private void editCounselor(Counselor counselor){
		// TODO 
	}
	private void createCourse(Course course){
		// TODO
	}
	private void removeCourse(Course course){
		// TODO
	}
	private void editCourse(Course course){
		// TODO 
	}
	private void createAdministrator(Administrator administrator){
		// TODO
	}
	private void removeAdministrator(Administrator administrator){
		// TODO
	}
	private void editAdministrator(Administrator administrator){
		// TODO 
	}
}
