/* Person.java
 * Brett Haines
 * Sept. 19, 2016
 * 
 * This abstract class defines the Person object, which is extended by all
 * objects representing persons in the University system.
 */


public abstract class Person {

	protected String name;
	protected String address;
	protected long phone;
	protected int uuid;
	
	public void changeName(String newName) { name = newName; }
	
	public String getName() { return name; }
	
	public void changeAddress(String newAddress) { address = newAddress; }
	
	public String getAddress() { return address; }
	
	public void changePhone(long newPhone) { phone = newPhone; }
	
	public long getPhone() { return phone; }
	
	public int getUUID() { return uuid; }
	
}
