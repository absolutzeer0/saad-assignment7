/* Instructor.java
 * Brett Haines
 * Oct 24, 2016
 * 
 * This class defines the Instructor object, which represent a single faculty
 * member of the University system.
 */


import java.util.ArrayList;


public class Instructor extends Person {

	private ArrayList<Course> teachableCourses;
	private ArrayList<Course> recentlyTaught;
	
	
	// Instructor constructor
	public Instructor(String name, String address, long phone, int id)
	{
		// Set Person class attributes
		super.changeName(name);
		super.changeAddress(address);
		super.changePhone(phone);
		super.uuid = id;
		
		// Create empty lists for 2 instance vars
		teachableCourses = new ArrayList<Course>();
		recentlyTaught = new ArrayList<Course>();
	}
	
	
	// Methods to add to and remove from lists
	public boolean addTeachableCourse(Course newCourse)
	{
		return teachableCourses.add(newCourse);
	}
	
	public boolean addRecentlyTaught(Course newCourse)
	{
		return recentlyTaught.add(newCourse);
	}
	
	public boolean removeRecentlyTaught(Course oldCourse)
	{
		return recentlyTaught.remove(oldCourse);
	}
	
	public ArrayList<Course> getTeachableCourses()
	{
		return teachableCourses;
	}
	
	public ArrayList<Course> getRecentlyTaught()
	{
		return recentlyTaught;
	}
	
	
	// Methods to interact with the Course and Session classes
	public boolean teach(Session session)
	{
		addRecentlyTaught(session.getCourse());
		return session.getInstructors().add(this);
	}
	
	public boolean addStudent(Session session, Student student)
	{
		return session.getStudents().add(student);
	}
	
	public boolean addSession(Course course, int year, Semester sem)
	{
		// Create new Session object
		Session newSession = new Session(year, sem, course);
		
		// Add self to list of instructors
		teach(newSession);
		
		// Add new session to list of sessions in Course object
		return course.getSessions().add(newSession);
	}
	
	
	// Methods to give grades and comment on student records
	public void giveGrade(Student student, Session session, String grade)
	{
		// Set grade for CoursePerformance on session
		getPerformanceForSession(student, session).setGrade(grade);
	}
	
	public void setNote(Student student, Session session, String note)
	{
		// Set instructor's note for CoursePerformance on session
		getPerformanceForSession(student, session).setNotes(note);
	}
	
	
	// Helper method
	private CoursePerformance getPerformanceForSession(Student student, 
			Session session)
	{
		// Determine if a CoursePerformance already exists for session
		for( CoursePerformance cp : student.getRecord().getPerformances() )
		{
			if( session.equals(cp.getSession()) )
				return cp;
		}
		
		// If this is reached, no CoursePerformance exists; a new object is
		// created, added to the student's record, and returned
		CoursePerformance performance = 
				new CoursePerformance(session.getCourse(), session);
		student.getRecord().addCP(performance);
		return performance;
	}
	
}
