/* Semester.java
 * Brett Haines
 * Oct 24, 2016
 * 
 * Semester is an enum used by the Session object to define which term a session
 * takes place in.
 */


public enum Semester {
	SPRING,
	SUMMER,
	FALL
}
