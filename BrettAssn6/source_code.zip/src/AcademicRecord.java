import java.util.ArrayList;


public class AcademicRecord {

	private ArrayList<CoursePerformance> courses;
	
	public AcademicRecord()
	{
		courses = new ArrayList<CoursePerformance>();
	}
	
	public ArrayList<CoursePerformance> getPerformances()
	{
		return courses;
	}
	
	public boolean addCP(CoursePerformance CP)
	{
		for(CoursePerformance performance : courses)
		{
			if( performance.getSession() != null && 
				performance.getSession().equals(CP.getSession()) )
				return false;
		}
		return courses.add(CP);
		
	}
}
