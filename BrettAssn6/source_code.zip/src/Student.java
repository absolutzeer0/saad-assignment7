/* Student.java
 * Brett Haines
 * Oct 24, 2016
 * 
 * This class defines the Student object, which represent a single student, past
 * or present, in the University system.
 */


import java.util.ArrayList;


public class Student extends Person {

	// Instance variables
	private boolean isEmployed;
	private ArrayList<Course> currentCourses;
	private AcademicRecord record;
	
	// Student class constructor
	public Student(String name, String address, long phone, int id)
	{
		// Set Person class attributes
		super.changeName(name);
		super.changeAddress(address);
		super.changePhone(phone);
		super.uuid = id;
		
		// Create empty list for current courses and new AcademicRecord object
		currentCourses = new ArrayList<Course>();
		record = new AcademicRecord();
		isEmployed = false;
	}
	
	// Getters and setters
	public void setEmployed(boolean bool) { isEmployed = bool; }
	
	public boolean getEmployed() { return isEmployed; }
	
	public AcademicRecord getRecord() { return record; }

	public ArrayList<Course> getCurrentCourses() { return currentCourses; }

	public void addCourse(Course newCourse) {currentCourses.add(newCourse); }
	
	// Helper functions
	public boolean hasPassedCourse(Course cor)
	{
		for(CoursePerformance cp : record.getPerformances())
		{
			if(cp.getCourse().equals(cor) && cp.getGrade().matches("[abcdABCD]")) return true;
		}
		
		// If we get here, then the Student has never passed the Course
		return false;
	}
	
}
