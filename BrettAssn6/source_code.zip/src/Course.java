/* Course.java
 * Brett Haines
 * Oct 24, 2016
 * 
 * This class defines the Course object, which represent one course in the
 * University's curriculum.
 */


import java.util.ArrayList;
import java.util.Iterator;


public class Course {

	// Instance variables
	private String title;
	private String description;
	private int courseID;
	private int enrollLimit;  
	private ArrayList<Course> prerequisites;
	private ArrayList<Session> sessions;
	private ArrayList<Student> students;
	private ArrayList<Instructor> teachers;
	private ArrayList<RequestEnrollment> requests;
	
	// Course class constructors
	public Course(String title, String description, int id)
	{
		setTitle(title);
		setDescription(description);
		courseID = id;
		enrollLimit = 0;
		sessions = new ArrayList<Session>();
		students = new ArrayList<Student>();
		prerequisites = new ArrayList<Course>();
		teachers = new ArrayList<Instructor>();
		requests = new ArrayList<RequestEnrollment>();
	}
	
	public Course() { this("", "", -1); }
	
	// Getters and setters
	public String getTitle() { return title; }

	public void setTitle(String newTitle) { title = newTitle; }

	public String getDescription() { return description; }

	public void setDescription(String newDescription) 
	{ 
		description = newDescription; 
	}
	
	public int getUUID() { return courseID; }
	
	public void setUUID(int id) { courseID = id; }
	
	public int getEnrollLimit() { return enrollLimit; }

	public void setEnrollLimit(int newLim) { enrollLimit = newLim; }
	
	public void addSeats(int diff) { enrollLimit += diff; }

	public ArrayList<Student> getStudents() { return students; }
	
	public void addStudent(Student stu) { students.add(stu); }
	
	public ArrayList<Session> getSessions() { return sessions; }
	
	public void addPrerequisite(Course cor) { prerequisites.add(cor); }
	
	public ArrayList<Course> getPrerequisites() { return prerequisites; }

	public void addInstructor(Instructor newInst) { teachers.add(newInst); }

	public ArrayList<Instructor> getInstructors() { return teachers; }

	public ArrayList<RequestEnrollment> getRequests() { return requests; }
	
	public void addRequest(RequestEnrollment req) { requests.add(req); }
	
	// Helper function
	public boolean moveRequestToBack(RequestEnrollment req)
	{
		if(!requests.contains(req))
			return false;
		
		for(Iterator<RequestEnrollment> iter = requests.iterator(); iter.hasNext(); )
		{
			if(iter.next().equals(req)) iter.remove();
		}
		
		requests.add(req);
		return true;
	}
	
}
