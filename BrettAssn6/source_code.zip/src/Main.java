/* Main.java
 * Brett Haines
 * Oct 24, 2016
 * 
 * This main class executes the main functions of reading in CSV files and
 * generating the digests.
 */


import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;


public class Main
{
	// Instance vars
	private static Student[] students = new Student[5000];
	private static int numStudents = 0;
	private static Instructor[] instructors = new Instructor[1000];
	private static int numInstructors = 0;
	private static Course[] courses = new Course[1000];
	private static int numCourses = 0;
	private static int numRecords = 0;
	private static int numRequests = 0;

	public static void main(String[] args)
	{
		// Read in CSV files
		readStudentsCSV("students.csv");
		readCoursesCSV("courses.csv");
		readInstructorsCSV("instructors.csv");
		readRecordsCSV("records.csv");
		readPrereqsCSV("prereqs.csv");
		readAssignmentsCSV("assignments.csv");
		readRequestsCSV("requests.csv");
		
		// Generate and print the digest
	/* 
		// ASSIGNMENT 3 DIGEST
		System.out.println(numRecords);
		System.out.println(numStudents);
		System.out.println(countClasslessStudents());
		System.out.println(numInstructors);
		System.out.println(countInstructorsNoTaught());
		System.out.println(numCourses);
		System.out.println(countStudentlessCourses());
		System.out.println(countSemesterSize(Semester.FALL));
		System.out.println(countSemesterSize(Semester.SPRING));
		System.out.println(countSemesterSize(Semester.SUMMER));
	*/
		// ASSIGNMENT 6 DIGEST
		System.out.println(numRequests);
		System.out.println(countReasons(RequestReason.GRANTED));
		System.out.println(countReasons(RequestReason.UNMET_PREREQUISITES));
		System.out.println(countReasons(RequestReason.ALREADY_TAKEN));
		System.out.println(countReasons(RequestReason.NO_AVAILABLE_SEATS));
		
		// Start command prompt
		System.out.print("$main: ");
		String cmd = "";
		Scanner input = new Scanner(System.in);
		while(true)
		{
			cmd = input.nextLine();
			String[] splitInput = cmd.split(",");
			switch(splitInput[0])
			{
				case "display_requests": 
					displayRequests();
					break; 
				case "display_records": 
					displayRecords();
					break; 
				case "display_seats":
					displaySeats();
					break; 
				case "add_record":
					addRecord(Integer.parseInt(splitInput[1]), 
							Integer.parseInt(splitInput[2]), 
							Integer.parseInt(splitInput[3]), 
							splitInput[4], 
							splitInput[5]);
					break; 
				case "add_seats":
					addSeats(Integer.parseInt(splitInput[1]), 
							Integer.parseInt(splitInput[2]));
					break; 
				case "check_request": 
					checkRequest(Integer.parseInt(splitInput[1]), 
							Integer.parseInt(splitInput[2]));
					break; 
				case "quit": 
					System.out.println("> stopping the command loop");
					input.close();
					System.exit(0);
				default: 
					System.out.println("> please enter a valid command.");
					break;
			}
			System.out.print("$main: ");
		}
	}
	
	
	// ************************************************************************
	// CSV READING FUNCTIONS
	// ************************************************************************

	private static boolean readStudentsCSV(String filepath)
	{
		Scanner input = null;
		File file = new File(filepath);
		
		try
		{
			// Create Scanner to read in file
			input = new Scanner(file);
			
			// Read in lines so long as there are more
			while(input.hasNextLine())
			{
				// Read and decompose line into elements
				String[] lineDecomp = input.nextLine().split(",");
				
				// Determine elements of new Student object
				int id = Integer.parseInt(lineDecomp[0]);
				String name = lineDecomp[1];
				String address = lineDecomp[2];
				long phone = Long.parseLong(lineDecomp[3]);
				
				// Add new Student to list of students
				students[id] = new Student(name, address, phone, id);
				numStudents++;
			}
			
			// Close input stream
			input.close();
		}
		catch(FileNotFoundException ex)
		{
			System.err.println(ex + " in readStudentsCSV.");
			ex.printStackTrace();
			return false;
		}
		catch(Exception ex)
		{
			System.err.println(ex + " in readStudentsCSV.");
			ex.printStackTrace();
			input.close();
			return false;
		}
		
		return true;
	}
	
	private static boolean readCoursesCSV(String filepath)
	{
		Scanner input = null;
		File file = new File(filepath);
		
		try
		{
			// Create Scanner to read in file
			input = new Scanner(file);
			
			// Read in lines so long as there are more
			while(input.hasNextLine())
			{
				// Create new Course object
				Course course = new Course();
				
				// Read and decompose line into elements
				String[] lineDecomp = input.nextLine().split(",");
				
				// Determine attributes of Course object
				int id = Integer.parseInt(lineDecomp[0]);
				course.setUUID(id);
				course.setTitle(lineDecomp[1]);
				
				/* Determine the semesters this course is being offered and
				 * create a Session object for each.
				 */
				for(int index = 2; index < lineDecomp.length; index++)
				{
					String semester = lineDecomp[index].toUpperCase();
					Semester sem = Semester.valueOf(semester);
					Session session = new Session(2017, sem, course);
					course.getSessions().add(session);
				}
				
				// Add new Course to list of courses
				courses[id] = course;
				numCourses++;
			}
			
			// Close input stream
			input.close();
		}
		catch(FileNotFoundException ex)
		{
			System.err.println(ex + " in readCoursesCSV.");
			ex.printStackTrace();
			return false;
		}
		catch(Exception ex)
		{
			System.err.println(ex + " in readCoursesCSV.");
			ex.printStackTrace();
			input.close();
			return false;
		}
		
		return true;
	}
	
	private static boolean readInstructorsCSV(String filepath)
	{
		Scanner input = null;
		File file = new File(filepath);
		
		try
		{
			// Create Scanner to read in file
			input = new Scanner(file);
			
			// Read in lines so long as there are more
			while(input.hasNextLine())
			{
				// Read and decompose line into elements
				String[] lineDecomp = input.nextLine().split(",");
				
				// Determine elements of new Instructor object
				int id = Integer.parseInt(lineDecomp[0]);
				String name = lineDecomp[1];
				String address = lineDecomp[2];
				long phone = Long.parseLong(lineDecomp[3]);
				
				// Add new Instructor to list
				instructors[id] = new Instructor(name, address, phone, id);
				numInstructors++;
			}
			
			// Close input stream
			input.close();
		}
		catch(FileNotFoundException ex)
		{
			System.err.println(ex + " in readInstructorsCSV.");
			ex.printStackTrace();
			return false;
		}
		catch(Exception ex)
		{
			System.err.println(ex + " in readInstructorsCSV.");
			ex.printStackTrace();
			input.close();
			return false;
		}
		
		return true;
	}
	
	private static boolean readRecordsCSV(String filepath)
	{
		Scanner input = null;
		File file = new File(filepath);
		
		try
		{
			// Create Scanner to read in file
			input = new Scanner(file);
			
			// Read in lines so long as there are more
			while(input.hasNextLine())
			{
				// Read and decompose line into elements
				String[] lineDecomp = input.nextLine().split(",");
				
				// Parse elements of the input line
				int studentID = Integer.parseInt(lineDecomp[0]);
				int courseID = Integer.parseInt(lineDecomp[1]);
				int instrID = Integer.parseInt(lineDecomp[2]);
				String notes = lineDecomp[3];
				String grade = lineDecomp[4];
				
				// Add notes and grade to Student's academic record
				Instructor instr = instructors[instrID];
				Student student = students[studentID];
				Course course = courses[courseID];
				CoursePerformance cp = new CoursePerformance(course, instr, 
						grade, notes);
				
				// Add this Course Performance to Student's Academic Record
				student.getRecord().addCP(cp);
				course.addStudent(student);
				
				// Add this course to the Instructor's recently taught list
				instr.addRecentlyTaught(course);
				
				numRecords++;
			}
			
			// Close input stream
			input.close();
		}
		catch(FileNotFoundException ex)
		{
			System.err.println(ex + " in readRecordsCSV.");
			ex.printStackTrace();
			return false;
		}
		catch(Exception ex)
		{
			System.err.println(ex + " in readRecordsCSV.");
			ex.printStackTrace();
			input.close();
			return false;
		}
		
		return true;
	}
	
	private static boolean readPrereqsCSV(String filepath)
	{
		Scanner input = null;
		File file = new File(filepath);
		
		try
		{
			// Create Scanner to read in file
			input = new Scanner(file);
			
			// Read in lines so long as there are more
			while(input.hasNextLine())
			{
				// Read and decompose line into elements
				String[] lineDecomp = input.nextLine().split(",");
				
				// Get the IDs of the course and its new prerequisite
				int prereq = Integer.parseInt(lineDecomp[0]);
				int id = Integer.parseInt(lineDecomp[1]);
				
				// Add new prerequisite to Course list
				courses[id].getPrerequisites().add(courses[prereq]);
			}
			
			// Close input stream
			input.close();
		}
		catch(FileNotFoundException ex)
		{
			System.err.println(ex + " in readPrereqsCSV.");
			ex.printStackTrace();
			return false;
		}
		catch(Exception ex)
		{
			System.err.println(ex + " in readPrereqsCSV.");
			ex.printStackTrace();
			input.close();
			return false;
		}
		
		return true;
	}
	
	private static boolean readAssignmentsCSV(String filepath)
	{
		Scanner input = null;
		File file = new File(filepath);
		
		try
		{
			// Create Scanner to read in file
			input = new Scanner(file);
			
			// Read in lines so long as there are more
			while(input.hasNextLine())
			{
				// Read and decompose line into elements
				String[] lineDecomp = input.nextLine().split(",");
				
				// Get the instructor ID, course ID, and number of seats open
				int inst = Integer.parseInt(lineDecomp[0]);
				int cor = Integer.parseInt(lineDecomp[1]);
				int seats = Integer.parseInt(lineDecomp[2]);
				
				// Add Instructor and new available seats to Course
				courses[cor].addInstructor(instructors[inst]);
				courses[cor].addSeats(seats);
			}
			
			// Close input stream
			input.close();
		}
		catch(FileNotFoundException ex)
		{
			System.err.println(ex + " in readAssignmentsCSV.");
			ex.printStackTrace();
			return false;
		}
		catch(Exception ex)
		{
			System.err.println(ex + " in readAssignmentsCSV.");
			ex.printStackTrace();
			input.close();
			return false;
		}
		
		return true;
	}
	
	private static boolean readRequestsCSV(String filepath)
	{
		Scanner input = null;
		File file = new File(filepath);
		
		try
		{
			// Create Scanner to read in file
			input = new Scanner(file);
			
			// Read in lines so long as there are more
			while(input.hasNextLine())
			{
				// Read and decompose line into elements
				String[] lineDecomp = input.nextLine().split(",");
				
				// Get the student and course IDs
				int stu = Integer.parseInt(lineDecomp[0]);
				int cor = Integer.parseInt(lineDecomp[1]);
				
				// Add a new request for that class
				RequestEnrollment req = new RequestEnrollment(students[stu],
						courses[cor]);
				courses[cor].addRequest(req);
				req.processRequest();
				numRequests++;
			}
			
			// Close input stream
			input.close();
		}
		catch(FileNotFoundException ex)
		{
			System.err.println(ex + " in readRequestsCSV.");
			ex.printStackTrace();
			return false;
		}
		catch(Exception ex)
		{
			System.err.println(ex + " in readRequestsCSV.");
			ex.printStackTrace();
			input.close();
			return false;
		}
		
		return true;
	}
	
	
	// ************************************************************************
	// DIGEST FUNCTIONS
	// ************************************************************************

	private static int countClasslessStudents()
	{
		int studs = 0;
		for(Student s : students)
		{
			if( s != null && s.getRecord().getPerformances().size() == 0 )
				studs++;
		}
		return studs;
	}
	
	private static int countInstructorsNoTaught()
	{
		int instrs = 0;
		for(Instructor i : instructors)
			if( i != null && i.getRecentlyTaught().size() == 0 ) instrs++;
		
		return instrs;
	}
	
	private static int countStudentlessCourses()
	{
		int coursesCount = 0;
		for(Course c : courses)
			if(c != null && c.getStudents().size() == 0)
				coursesCount++;
			
		return coursesCount;
	}
	
	private static int countSemesterSize(Semester sem)
	{
		int semCount = 0;
		for(Course c : courses)
		{
			if(c != null && c.getSessions().size() != 0)
				for(Session s : c.getSessions())
					if(s.getSemester() == sem) semCount++;
		}
		return semCount;
	}
	
	private static int countReasons(RequestReason reason)
	{
		int count = 0;
		
		for(Course cor : courses)
		{
			if(cor != null)
				for(RequestEnrollment req : cor.getRequests())
					if(req.getReason() == reason) count++;
		}
		return count;
	}
	
	// Display all granted requests
	private static void displayRequests()
	{
		for(Course cor : courses)
		{
			if(cor != null)
				for(RequestEnrollment req : cor.getRequests())
					if(req.getReason() == RequestReason.GRANTED)
					{
						int stuID = req.getStudent().getUUID();
						int corID = cor.getUUID();
						String stuName = req.getStudent().getName();
						String corName = cor.getTitle();
						
						System.out.println(stuID + ", " + stuName + ", " + 
								corID + ", " + corName);
					}
		}
	}
	
	private static void displaySeats()
	{
		for(Course c : courses)
			if(c != null)
				System.out.println(c.getUUID() + ", " + c.getTitle() + ", " +
						c.getEnrollLimit());
	}
	
	private static void displayRecords()
	{
		for(Student s : students)
			if(s != null)
				for(CoursePerformance cp : s.getRecord().getPerformances())
				{
					int stuID = s.getUUID();
					int corID = cp.getCourse().getUUID();
					int instID = cp.getInstructor().getUUID();
					String comment = cp.getNotes();
					String grade = cp.getGrade();
					
					System.out.println(stuID + ", " + corID + ", " + instID + 
							", " + comment + ", " + grade);
				}
	}
	
	private static void checkRequest(int studentID, int courseID)
	{
		Student stu = students[studentID];
		Course cor = courses[courseID];
		
		for(RequestEnrollment req : cor.getRequests())
		{
			if(req.getStudent().equals(stu))
			{
				req.processRequest();
				switch(req.getReason())
				{
					case UNMET_PREREQUISITES:
						System.out.println("> student is missing one or more prerequisites");
						return;
					case ALREADY_TAKEN:
						System.out.println("> student has already taken the course with a grade of C or higher");
						return;
					case NO_AVAILABLE_SEATS:
						System.out.println("> no remaining seats available for the course at the time");
						return;
					case GRANTED:
						System.out.println("> request is valid");
						return;
					default:
						System.out.println("> unknown error has occurred");
						break;
				}
			}
		}
		
		// If we get here, then no such request exists
		System.out.println("> no such request exists");
	}
	
	private static void addRecord(int studentID, int courseID, int instID,
												String comment, String grade)
	{
		Student stu = students[studentID];
		Course cor = courses[courseID];
		Instructor inst = instructors[instID];
		
		CoursePerformance cp = new CoursePerformance(cor, inst, grade, comment);
		stu.getRecord().addCP(cp);
	}
	
	private static void addSeats(int courseID, int newSeats)
	{
		courses[courseID].addSeats(newSeats);
	}
	
}
