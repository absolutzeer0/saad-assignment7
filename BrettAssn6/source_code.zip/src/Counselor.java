/* Counselor.java
 * Brett Haines
 * Sept. 19, 2016
 * 
 * This class defines the Counselor object, which represent an academic
 * counselor employed by the University.
 */


import java.util.ArrayList;


public class Counselor extends Person {

	private ArrayList<Student> students;
	
	// Counselor class constructor
	public Counselor(String name, String address, long phone, int id)
	{
		// Set Person class attributes
		super.changeName(name);
		super.changeAddress(address);
		super.changePhone(phone);
		super.uuid = id;
		
		// Create empty Student list
		students = new ArrayList<Student>();
	}
	
	// Methods to add and remove students from list
	public boolean addStudent(Student newStudent)
	{
		return students.add(newStudent);
	}
	
	public boolean removeStudent(Student oldStudent)
	{
		return students.remove(oldStudent);
	}
	
	// Method to interact with Student class
	public void approveCourseList(Student student, boolean approved)
	{
		// Does nothing yet.
	}
	
}
