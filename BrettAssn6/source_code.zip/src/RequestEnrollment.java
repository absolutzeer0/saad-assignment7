
public class RequestEnrollment {

	private int year;
	private RequestReason reason;
	private Semester sem;
	private Student student;
	private Course course;

	public RequestEnrollment(Student stu, Course cor)
	{
		// Assign instance variables
		setStudent(stu);
		course = cor;
		reason = RequestReason.PENDING;
		
		// Add this request to the course's request queue
		course.getRequests().add(this);
	}
	
	public void recindRequest()
	{
		course.getRequests().remove(this);
		setReason(RequestReason.REQUEST_RECINDED);
	}

	// Getters and Setters
	public int getYear() { return year; }

	public void setYear(int year) { this.year = year; }

	public RequestReason getReason() { return reason; }

	public void setReason(RequestReason reason) { this.reason = reason; }

	public Student getStudent() { return student; }

	public void setStudent(Student student) { this.student = student; }
	
	// Helpers functions
	public boolean processRequest()
	{
		// Skip if it's already been approved
		if(reason == RequestReason.GRANTED)
			return true;
		
		// Ensure student has passed prerequisite courses
		for(Course prereq : course.getPrerequisites())
		{
			if(!student.hasPassedCourse(prereq))
			{
				setReason(RequestReason.UNMET_PREREQUISITES);
				course.moveRequestToBack(this);
				return false;
			}
		}
		
		// Ensure student hasn't already earned a "good" grade in this course
		for(CoursePerformance cp : student.getRecord().getPerformances())
		{
			if(cp.getCourse().equals(course) && cp.getGrade().matches("[abcABC]"))
			{
				setReason(RequestReason.ALREADY_TAKEN);
				course.moveRequestToBack(this);
				return false;
			}
		}
		
		// Check course availability
		if(course.getEnrollLimit() <= 0)
		{
			setReason(RequestReason.NO_AVAILABLE_SEATS);
			course.moveRequestToBack(this);
			return false;
		}
		
		// If all conditions are met, add student to course
		setReason(RequestReason.GRANTED);
		course.addSeats(-1);
		course.moveRequestToBack(this);
		course.addStudent(student);
		return true;
	}
}
