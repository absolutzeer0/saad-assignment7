/* Session.java
 * Brett Haines
 * Sept. 19, 2016
 * 
 * This class defines the Session object, which represent a single session of
 * a Course in the Univerity curriculum.
 */


import java.util.ArrayList;


public class Session {
	
	// Instance vars
	private int year;
	private Semester semester;
	private Course course;
	private ArrayList<Instructor> instructors;
	private ArrayList<Student> students;
	private int sessionID;
	
	// Session class constructor
	public Session(int newYear, Semester sem, Course newCourse)
	{
		// Set instance vars
		year = newYear;
		semester = sem;
		course = newCourse;
		
		// Create empty lists for Instructors and students
		instructors = new ArrayList<Instructor>();
		students = new ArrayList<Student>();
		
		// Generate sessionID from number of sessions already existing
		sessionID = 0;
	}

	
	// Getters and setters
	public int getYear() { return year; }
	
	public void setYear(int newYear) { year = newYear; }
	
	public Semester getSemester() { return semester; }
	
	public void setSemester(Semester newSemester) { semester = newSemester; }
	
	public int getSessionID() { return sessionID; }
	
	public Course getCourse() { return course; }
	
	public ArrayList<Instructor> getInstructors() { return instructors; }
	
	public ArrayList<Student> getStudents() { return students; }
	
}
