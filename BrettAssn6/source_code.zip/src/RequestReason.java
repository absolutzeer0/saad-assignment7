/* RequestReason.java
 * Brett Haines
 * Oct. 24, 2016
 * 
 * RequestReason is an enum used to give reasons as to why a request for
 * enrollment in a course was granted or denied.
 */


public enum RequestReason {
	PENDING,
	GRANTED,
	ALREADY_TAKEN,
	NO_AVAILABLE_SEATS,
	UNMET_PREREQUISITES,
	REQUEST_RECINDED
}
