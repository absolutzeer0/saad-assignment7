/* CoursePerformance.java
 * Brett Haines
 * Oct 24, 2016
 * 
 * This class defines the CoursePerformance object, which represent a review of
 * a student's performance (grade and instructor's notes) in a course.
 */


public class CoursePerformance {

	// Instance variables
	private Course course;
	private Session session;
	private Instructor instructor;
	private String grade;
	private String instructorNotes;
	
	
	// CoursePerformance class constructors
	public CoursePerformance(Course course, Instructor inst, String grade, 
			String note)
	{
		this.course = course;
		this.grade = grade;
		instructorNotes = note;
		instructor = inst;
	}
	
	public CoursePerformance(Course course, Session session)
	{
		this.course = course;
		this.session = session;
	}
	
	
	// Getters and setters
	public Session getSession() { return session; }

	public Course getCourse() { return course; }
	
	public String getGrade() { return grade; }
	
	public void setGrade(String newGrade) { grade = newGrade; }
	
	public String getNotes() { return instructorNotes; }
	
	public void setNotes(String newNote) { instructorNotes = newNote; }

	public Instructor getInstructor() { return instructor; }

	public void setInstructor(Instructor inst) { instructor = inst; }
}
